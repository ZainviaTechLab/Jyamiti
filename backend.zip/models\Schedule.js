import mongoose from 'mongoose';

const scheduleSchema = new mongoose.Schema({
  batch: { type: mongoose.Schema.Types.ObjectId, ref: 'Batch', required: true },
  date: { type: Date, required: true },
  startTime: { type: String, required: true },
  endTime: { type: String, required: true },
  isCancelled: { type: Boolean, default: false },
}, { timestamps: true });

export default mongoose.model('Schedule', scheduleSchema);
