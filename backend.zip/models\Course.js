import mongoose from 'mongoose';

const courseSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  description: { type: String, default: '' },
  grade: { type: String, default: '' },
  subject: { type: String, default: '' },
  syllabus: [
    {
      title: { type: String, required: true }, // Chapter/Unit
      topics: [
        {
          title: { type: String, required: true }, // Topic
          subTopics: [
            {
              title: { type: String, required: true } // Sub-topic
            }
          ]
        }
      ]
    }
  ]
}, { timestamps: true });

export default mongoose.model('Course', courseSchema);
